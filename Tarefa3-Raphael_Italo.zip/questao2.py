from math import sin,cos,pi
x0,x1,x2,x3=[],[],[],[]
y0,y1,y2,y3=[],[],[],[]
resultados=[]
for i in xrange(0,8):
	x0.append(1);
	x1.append(i)
	x2.append(7-i)
	x3.append(i)
	y0.append(0)
	y1.append(sin(i))
	y2.append(cos(7-i))
	y3.append(i)
	resultados.append(-pi+0.565*sin(i)+2.657*cos(i)+0.674*i)	
peso0,peso1,peso2,peso3=0,0,0,0
N=8
eta=0.1
print resultados
#valores corretos
a1,a2,a3,a0=0.565,2.657,0.674,-pi


for epoca in xrange(0,75):
	somatorio_erro_quadrado=0
        somatorio_erro_x=0
	somatorio_erro_x0=0	
	#funcao 1
        for i in xrange(0,N):
                erro=(y1[i]-(x1[i]*peso1))#+x2[i]*peso2+x3[i]*peso3+peso0))
                somatorio_erro_quadrado+=pow(erro,2)
                erro_x1=erro*x1[i]
		erro_x0=erro
		erro_x2=erro*x2[i]
		erro_x3=erro*x3[i]
#                somatorio_erro_x+=erro_x
 #               somatorio_erro_x0+=erro_x0
	        print "erro: ",erro," som: ",somatorio_erro_quadrado
       		dw1=eta*erro_x1
		dw0=eta*erro_x0
		dw2=eta*erro_x2
		dw3=eta*erro_x3
       		peso1+=dw1
        	peso2+=dw2
       		peso3+=dw3
        	peso0+=dw0

	eqm=(1/(2.0*N))*somatorio_erro_quadrado
#       for i in xrange(0,N):
#        if ((epoca+1)%3==0):
        print epoca,"peso0:",peso0,"peso1:",peso1,"peso2",peso2,"peso3",peso3,"EQM:",eqm
#print w0



